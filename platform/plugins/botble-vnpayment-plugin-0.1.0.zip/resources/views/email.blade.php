<strong>{{ trans('plugins/vnpay::vnpay.payment_details') }}: </strong>
@include('plugins/vnpay::detail', compact('payment'))
