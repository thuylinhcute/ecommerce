<?php

if (! defined('VNPAY_PAYMENT_METHOD_NAME')) {
    define('VNPAY_PAYMENT_METHOD_NAME', 'vnpay');
}
