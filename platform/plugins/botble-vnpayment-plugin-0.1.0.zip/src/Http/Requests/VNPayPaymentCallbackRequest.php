<?php

namespace Binjuhor\VNPay\Http\Requests;

use Botble\Support\Http\Requests\Request;

class VNPayPaymentCallbackRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
